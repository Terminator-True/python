from django.apps import AppConfig


class VistesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vistes'
