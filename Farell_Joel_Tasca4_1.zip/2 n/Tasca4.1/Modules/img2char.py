"""
Es el programa principal. Dels arguments que se li passen n’obt ́e una cadena de car`acters  ́
corresponent als d ́ıgits de la matr ́ıcula.
"""