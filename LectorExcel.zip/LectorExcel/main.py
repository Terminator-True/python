from tkinter import *
from tkinter import messagebox
import os

try:
    import pandas as pd
except:
    from instalador import main
    print("Library pandas not installed, installing....")
    main()
    os.system("pip install pandas")


#Objeto encargado de buscar la información y colocarla en una matriz 
class Info:
    #Pasamos el archivo que queremos por parámetro
    def __init__(self, archivo):
        self.archivo=archivo
    
    #Lee el archivo y hace return de éste
    def get_info(self):
        info=pd.read_excel(io=self.archivo,sheet_name="BQ1.XLS",header=None)
        return info
    #Llama al anterior método y recorre lo que necesitamos metiéndolo
    # a su vez en una matriz de dos dimensiones
    def tidy(self):
        info=self.get_info()
        return [[info[i][j] for j in range(6,len(info[i]))]for i in info[[1,3,8,9]]]

#Objeto encargado de crear y modificar la ventana de Tkinter
class Ventana:
    #Pasamos la ventana por parámetro y la información devuelta por el anterior objeto
    def __init__(self, master,info):
        #Definición de variables necesarias
        self.master = master
        self.info=info
        self.num=1     
        #Configuración básica de la ventana
        master.title("Info")
        master.configure(width=300, height=200)
        #Definición del botón que muestra lína a línea la información
        self.boton=Button(master, text="Siguiente línea",width=12,height=1,command=lambda:self.posicionar()).grid(row=0,column=5)

    #Funció a la que se llama al hacer click sobre el botón
    #Va mostrando línea a línea la información haciendo uso de la variable self.num
    #Cada vez que hacemos click, éste agrega una línea a la ventana, cuando no hay más líneas
    #crea una pequeña caja de texto que nos avisa
    def posicionar(self):
        try:
            for i in range(len(self.info)):
                for j in range(self.num):
                    self.e = Entry(root, width=10, fg='blue', 
                                    font=('Arial',12,'bold')
                                    ) 
                    self.e.grid(row=j, column=i) 
                    self.e.insert(END, self.info[i][j]) 
            self.setNum(self.num+1)
        except IndexError:
            messagebox.showwarning(message="Error, no quedan más líneas", title="Error")
    #setters necesarios
    def setNum(self,num):
        self.num=num
        
#Programa principal
if __name__=="__main__":
    root = Tk()   
    arc=Info("LectorExcel\BQ1.xlsx")
    ventana = Ventana(root,arc.tidy())
    root.mainloop()
